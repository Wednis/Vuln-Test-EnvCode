package com.example.thymeleaftest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymeleaftestApplicationTests {

    @Test
    void contextLoads() {
    }

}
